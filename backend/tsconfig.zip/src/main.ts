import { NestFactory } from "@nestjs/core";
import { ValidationPipe } from "@nestjs/common";
import helmet from "helmet";
import { json, urlencoded, Express } from "express";
import * as cookieParser from "cookie-parser";
import * as express from "express";
import { AppModule } from "./app.module";

function getCorsOrigins(): string[] {
  return (process.env.CORS_ORIGINS || "http://localhost:3000,https://devspro.xyz,https://www.devspro.xyz,https://loti.nextboostperu.com")
    .split(",")
    .map(s => s.trim());
}

async function bootstrap() {
  process.on("unhandledRejection", (reason) => console.error("UNHANDLED REJECTION:", reason));
  process.on("uncaughtException", (err) => console.error("UNCAUGHT EXCEPTION:", err));

  const port = process.env.APP_PORT || 4000;
  const host = process.env.APP_HOST || "0.0.0.0";

  try {
    const app = await NestFactory.create(AppModule);

    app.use(cookieParser());
    app.enableCors({
      origin: getCorsOrigins(),
      methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
      credentials: true,
    });
    app.use(json({ limit: "10mb" }));
    app.use(urlencoded({ limit: "10mb", extended: true }));
    app.use(helmet({
      crossOriginResourcePolicy: { policy: "cross-origin" },
      contentSecurityPolicy: false,
    }));
    app.useGlobalPipes(new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }));
    app.setGlobalPrefix("api", { exclude: ["uploads/(.*)"] });
    app.enableShutdownHooks();

    await app.listen(port, host);
    console.log(`Lotifyx API running on http://${host}:${port}`);
  } catch (err) {
    console.error("NestJS startup failed (DB unreachable?), starting emergency server:", err.message);

    const emergencyApp: Express = express();
    emergencyApp.use(cookieParser());
    emergencyApp.use(helmet({
      crossOriginResourcePolicy: { policy: "cross-origin" },
      contentSecurityPolicy: false,
    }));
    emergencyApp.all("*", (_req, res) => {
      res.status(503).json({
        error: "Service unavailable",
        message: "Database connection failed. The server is running but cannot serve data.",
      });
    });
    emergencyApp.listen(Number(port), host, () => {
      console.log(`Emergency server listening on http://${host}:${port} (DB unavailable)`);
    });
  }
}
bootstrap();
